import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class MyinterceptorInterceptor implements HttpInterceptor {

  constructor() {
    
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   const mytoken=localStorage.getItem('Token')
    const modifyrequest=request.clone({
    setHeaders:{
      'Authorization':'Token '+mytoken
    }
    })
    return next.handle(modifyrequest);
  }
}
