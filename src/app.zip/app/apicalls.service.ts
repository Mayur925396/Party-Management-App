import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class APICallsService {
  
  constructor(private http: HttpClient) {

   }
   public baseUrl:any='https://pv.greatfuturetechno.com/'
   getData(): Observable<any>{
    return this.http.get(this.baseUrl+'pv-api/dealer/');
   }

   postData(data:any): Observable<any>{
    return this.http.post(this.baseUrl+"pv-api/dealer/",data)
   }
   deleteData(data:any): Observable<any>{
    return this.http.delete(this.baseUrl+"pv-api/dealer/?id="+data);
   }

   updateApiData(data:any): Observable<any>{
    return this.http.put(this.baseUrl+'pv-api/dealer/?id='+data.id,data)
   }
}
