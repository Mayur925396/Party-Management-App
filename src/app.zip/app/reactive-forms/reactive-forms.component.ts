import { Component, inject } from '@angular/core';
import { APICallsService } from '../apicalls.service';
import { HttpHeaders } from '@angular/common/http';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css'],
  providers:[DatePipe]

})
export class ReactiveFormsComponent {

  public dealerData: FormGroup;
  public dealerInfo:any=[];
  constructor(private ap: APICallsService, private fb: FormBuilder, private datePipe: DatePipe) {
    this.dealerData = this.fb.group({
      id:[''],
      login_access: [false],
      name: [''],
      company_name: [''],
      mobile_no: [''],
      telephone_no: [''],
      whatsapp_no: [''],
      remark: [''],
      date_of_birth: [''],
      anniversary_date: [''],
      gst_type: [''],
      gstin: [''],
      pan_no: [''],
      apply_tds: [false],
      credit_limit: [''],
      address: this.fb.array([
        this.createAddress()
      ]),
      bank_id: this.fb.array([
        this.createBank()
      ]),
      opening_balance: [''],
      supplier_type: [''],
      email: [''],
      opening_balance_type: ['']

    })
  }
  createAddress(): FormGroup {
    return this.fb.group({
      address_line_1: [''],
      address_line_2: [''],
      country: [''],
      state: [''],
      city: [''],
      pincode: [''],
      address_type: ['']
    })
  }
  createBank(): FormGroup {
    return this.fb.group({
      bank_ifsc_code: [''],
      bank_name: [''],
      branch_name: [''],
      account_no: [''],
      account_holder_name: ['']
    });
  }
  ngOnInit() {
    this.getApiDAta();
    localStorage.setItem('Token', '084f2df6319f2729c860fd3d1393840e41f56f00');
  }
  getApiDAta() {
    this.ap.getData().subscribe({
      next: (res: any) => {
        console.log(res);
        this.dealerInfo=res;
      },
      error: (err) => console.log(err),
      complete: () => console.log("Data gathered from api Successfully")

    })
  }


  SendApiDAta() {
    delete this.dealerData.value.id;
    this.ap.postData(this.dealerData.value).subscribe({
      next: (res: any) => {
        console.log(res);
        this.dealerInfo.push(this.dealerData.value);
      },
      error: (err) => console.log(err),
      complete: () => console.log("Data gathered from api Successfully")

    })
  }
  delete(data: any) {
    this.ap.deleteData(data).subscribe({
      next: (res: any) => {
        console.log(res);

        var index=this.dealerInfo.findIndex((x:any)=>x.id==data.id);
        this.dealerInfo.splice(index,1)
        console.log("Data Deleted successfully")
      }
    })
  }

  get address(): FormArray {
    return this.dealerData.get('address') as FormArray;
  }

  get bank_id(): FormArray {
    return this.dealerData.get('bank_id') as FormArray;
  }

  addAddress(): void {
    this.address.push(this.createAddress());
  }

  removeAddress(index: number): void {
    this.address.removeAt(index);
  }

  addBank(): void {
    this.bank_id.push(this.createBank());
  }

  removeBank(index: number): void {
    this.bank_id.removeAt(index);
  }

  
  createDealer() {
    console.log(this.dealerData.value);
    this.SendApiDAta();
  }
  formatDate(): void {
    const dateControl = this.dealerData.get('date_of_birth');
    if (dateControl && dateControl.value) {
      const formattedDate = this.datePipe.transform(new Date(dateControl.value), 'YYYY-MM-DD');
      dateControl.setValue(formattedDate, { emitEvent: false });
    }
}

update(data:any){
this.dealerData.patchValue({...data})
}

updateIt(){
  this.ap.updateApiData(this.dealerData.value).subscribe({
    next:(res:any)=>{
      console.log(res);
      this.dealerInfo.forEach((x:any,index:any)=>{
        if(x.id==res.id)
      this.dealerInfo.splice(index,1,res)
      })
    },
    error:(err:any)=>console.log(err)
    
  })
}
}
